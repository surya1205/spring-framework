package com.serole;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBooApplication
{
public static void main(String[] args) 
{
SpringApplication.run(SpringBooApplication.class, args);
}
}